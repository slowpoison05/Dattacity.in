// landing-intro.js

document.addEventListener("DOMContentLoaded", () => {
  const introOverlay = document.getElementById("villageIntroOverlay");
  const enterBtn = document.getElementById("enterVillageBtn");
  const skipBtn = document.getElementById("skipIntroBtn");
  
  if (!introOverlay) return;

  // Check if user has already seen the intro (Disabled to always show)
  // const hasSeenIntro = localStorage.getItem("dattaCityIntroSeen");
  // if (hasSeenIntro) {
  //   introOverlay.style.display = "none";
  //   document.body.classList.remove("village-intro-active");
  //   return;
  // }

  // Pre-load audio gracefully
  let doorAudio = null;
  try {
    doorAudio = new Audio('assets/audio/door-open.mp3');
    doorAudio.preload = 'auto';
  } catch (e) {
    console.warn("Audio not supported or blocked", e);
  }

  function playDoorSound() {
    if (doorAudio) {
      doorAudio.play().catch(e => console.log("Audio autoplay blocked by browser", e));
    }
  }

  function openVillage() {
    if (enterBtn) {
      enterBtn.disabled = true;
      enterBtn.innerHTML = '<span class="button-light"></span> प्रवेश हो रहा है...';
    }

    playDoorSound();

    // Trigger 3D opening animation
    introOverlay.classList.add("is-opening");
    document.body.classList.remove("village-intro-active");

    // Save state
    try {
      localStorage.setItem("dattaCityIntroSeen", "true");
    } catch(e) {}

    // Wait for the animation to finish (1s door + 1s fade = 2s)
    setTimeout(() => {
      introOverlay.classList.add("hidden");
      // Smooth scroll to top/dashboard if necessary
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 2000);
  }

  function skipVillageIntro() {
    try {
      localStorage.setItem("dattaCityIntroSeen", "true");
    } catch(e) {}
    introOverlay.style.display = "none";
    document.body.classList.remove("village-intro-active");
  }

  if (enterBtn) {
    enterBtn.addEventListener("click", openVillage);
  }

  if (skipBtn) {
    skipBtn.addEventListener("click", skipVillageIntro);
  }
});
