/**
 * Mandi Service for DattaCity
 * Handles fetching live agricultural market prices from data.gov.in
 * and falls back to a deterministic, daily-fluctuating mock rates generator
 * if no API key is present or the request fails.
 */

const MandiService = {
  API_URL: 'https://api.data.gov.in/resource/35985678-0d79-46b4-9ed6-6f13308a1d24',
  CACHE_KEY: 'dattacity_mandi_rates',
  // Hardcode your data.gov.in API key here to enable live rates automatically in the background
  API_KEY: '', 
  CACHE_EXPIRY: 12 * 60 * 60 * 1000, // 12 hours in milliseconds

  // Priority Mandis in Haryana
  MANDIS: [
    { key: 'Hisar', name: 'Hisar (हिसार)', district: 'Hisar' },
    { key: 'Hansi', name: 'Hansi (हांसी)', district: 'Hisar' },
    { key: 'Barwala', name: 'Barwala (बरवाला)', district: 'Hisar' },
    { key: 'Adampur', name: 'Adampur (आदमपुर)', district: 'Hisar' },
    { key: 'Sirsa', name: 'Sirsa (सिरसा)', district: 'Sirsa' },
    { key: 'Fatehabad', name: 'Fatehabad (फतेहाबाद)', district: 'Fatehabad' }
  ],

  // Priority Crops with their English/Hindi names and baseline prices
  CROPS: [
    { key: 'Wheat', hindi: 'गेहूं', min: 2150, max: 2350 },
    { key: 'Bajra', hindi: 'बाजरा', min: 2000, max: 2250 },
    { key: 'Cotton', hindi: 'कपास', min: 6600, max: 7100 },
    { key: 'Paddy', hindi: 'धान (बासमती)', min: 3900, max: 4250 },
    { key: 'Sarson', hindi: 'सरसों', min: 5100, max: 5500 },
    { key: 'Barley', hindi: 'जौ', min: 1750, max: 1950 },
    { key: 'Gram', hindi: 'चना', min: 4600, max: 4950 },
    { key: 'Guar', hindi: 'ग्वार', min: 4900, max: 5350 },
    { key: 'Moong', hindi: 'मूंग', min: 7000, max: 7500 },
    { key: 'Mustard', hindi: 'राय', min: 5200, max: 5650 }
  ],

  getApiKey() {
    return this.API_KEY || '';
  },



  // Generates deterministic daily fluctuating rates based on calendar date seed
  getMockRates() {
    const today = new Date();
    const dateStr = today.toISOString().split('T')[0]; // "YYYY-MM-DD"
    const seed = parseInt(dateStr.replace(/-/g, '')) || 20260607;
    
    const records = [];

    // Seed-based pseudo-random number generator
    const pseudoRandom = (s, offset) => {
      const x = Math.sin(s + offset) * 10000;
      return x - Math.floor(x);
    };

    this.MANDIS.forEach((mandi, mIdx) => {
      this.CROPS.forEach((crop, cIdx) => {
        // Generate a deterministic +/- 4% fluctuation daily per crop-mandi pair
        const offset = mIdx * 13 + cIdx * 7;
        const randVal = pseudoRandom(seed, offset);
        const fluctuation = (randVal - 0.5) * 0.08; // -4% to +4%
        
        const minPrice = Math.round(crop.min * (1 + fluctuation));
        const maxPrice = Math.round(crop.max * (1 + fluctuation));
        const modalPrice = Math.round((minPrice + maxPrice) / 2);

        records.push({
          state: 'Haryana',
          district: mandi.district,
          market: mandi.key,
          commodity: crop.key,
          variety: 'Local',
          arrival_date: today.toLocaleDateString('en-GB'), // DD/MM/YYYY
          min_price: minPrice.toString(),
          max_price: maxPrice.toString(),
          modal_price: modalPrice.toString(),
          isMock: true,
          updated_at: new Date().toLocaleTimeString('hi-IN', { hour: '2-digit', minute: '2-digit' })
        });
      });
    });

    return records;
  },

  // Calls Gov API to fetch latest rates
  async fetchLiveRates(apiKey) {
    if (!apiKey) throw new Error('API Key missing');

    // Build URL queries. Pull limits to 500 to cover all markets
    const url = `${this.API_URL}?api-key=${apiKey}&format=json&limit=500&filters[state]=Haryana`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`API response error: ${response.status}`);
    }
    const data = await response.json();
    if (!data.records || !Array.isArray(data.records)) {
      throw new Error('Invalid API response format');
    }
    
    // Normalize and filter Agmarknet responses for our priority mandis/crops
    const nowStr = new Date().toLocaleTimeString('hi-IN', { hour: '2-digit', minute: '2-digit' });
    const formattedRecords = data.records
      .filter(record => {
        const marketName = (record.market || '').toLowerCase();
        const commodityName = (record.commodity || '').toLowerCase();
        
        // Match priority mandis
        const matchesMandi = this.MANDIS.some(m => marketName.includes(m.key.toLowerCase()));
        // Match priority crops
        const matchesCrop = this.CROPS.some(c => commodityName.includes(c.key.toLowerCase()));
        
        return matchesMandi && matchesCrop;
      })
      .map(record => {
        // Find matching crop key
        const cropMatch = this.CROPS.find(c => (record.commodity || '').toLowerCase().includes(c.key.toLowerCase()));
        // Find matching mandi key
        const mandiMatch = this.MANDIS.find(m => (record.market || '').toLowerCase().includes(m.key.toLowerCase()));
        
        return {
          state: record.state || 'Haryana',
          district: record.district || mandiMatch?.district || '',
          market: mandiMatch?.key || record.market,
          commodity: cropMatch?.key || record.commodity,
          variety: record.variety || 'Local',
          arrival_date: record.arrival_date || new Date().toLocaleDateString('en-GB'),
          min_price: record.min_price,
          max_price: record.max_price,
          modal_price: record.modal_price,
          isMock: false,
          updated_at: nowStr
        };
      });

    return formattedRecords;
  },

  // Primary service interface with automatic caching and fallback rules
  async getRates(forceRefresh = false) {
    const apiKey = this.getApiKey();

    // Check Cache
    if (!forceRefresh) {
      const cached = localStorage.getItem(this.CACHE_KEY);
      if (cached) {
        try {
          const cacheData = JSON.parse(cached);
          if (Date.now() - cacheData.timestamp < this.CACHE_EXPIRY) {
            console.log('Serving Mandi rates from local storage cache');
            return cacheData.records;
          }
        } catch (e) {
          localStorage.removeItem(this.CACHE_KEY);
        }
      }
    }

    // Attempt Live Fetch if API key is present
    if (apiKey) {
      try {
        console.log('Fetching live Mandi rates from data.gov.in');
        const liveRecords = await this.fetchLiveRates(apiKey);
        
        // If live API returned zero records, fallback to mock data
        if (liveRecords.length === 0) {
          console.warn('API returned 0 records for Haryana priority mandis, falling back to mock data');
          return this.getMockRates();
        }

        // Cache success
        localStorage.setItem(this.CACHE_KEY, JSON.stringify({
          timestamp: Date.now(),
          records: liveRecords
        }));

        return liveRecords;
      } catch (error) {
        console.error('Mandi API Error, loading mock data fallback:', error);
        // Fallback to cache if available even if expired
        const cached = localStorage.getItem(this.CACHE_KEY);
        if (cached) {
          try {
            return JSON.parse(cached).records;
          } catch (_) {}
        }
        return this.getMockRates();
      }
    }

    // No API key configured: Load fallback mock data directly
    console.log('No API key set, serving deterministic mock rates');
    return this.getMockRates();
  }
};
